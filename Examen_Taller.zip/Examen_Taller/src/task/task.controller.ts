import { Controller } from '@nestjs/common';

@Controller('examen/v1/controller modulo')
export class TaskController {}
